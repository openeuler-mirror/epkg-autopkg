#!/usr/bin/env bash


build_system=meson
build_requires="meson make gcc g++"
source /root/.bashrc
yum install -y $build_requires
