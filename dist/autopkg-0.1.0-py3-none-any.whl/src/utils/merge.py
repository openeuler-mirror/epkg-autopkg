# SPDX-License-Identifier: MIT
# Copyright (c) 2017 Shintaro Kaneko. All rights reserved.


def merge_func(yaml_list: list):
    # TODO(merge多编译类型的字典数据)
    return {}
