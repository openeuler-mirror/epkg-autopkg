def merge_func(yaml_list: list):
    # TODO(merge多编译类型的字典数据)
    return {}
